﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;//inorder to use validations

namespace WebApplicationDemo.Models
{
    public class Employee
    {
        [Required]
        [Display(Name="Employee ID")]//to display this name in view
        [Range(0, int.MaxValue, ErrorMessage = "Please enter valid integer Number")]
        public int EmpId { get; set; }

        [Required]
        [StringLength(12)]
        [Display(Name="Employee Name")]
        public string EmpName { get; set; }

        [Required]
        [Range(1000,5000)]
        [Display(Name="Salary")]
        public int Salary { get; set; }
    }
}