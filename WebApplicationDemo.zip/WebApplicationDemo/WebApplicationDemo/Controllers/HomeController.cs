﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;
using WebApplicationDemo.Models;

namespace WebApplicationDemo.Controllers
{
    public class HomeController : Controller
    {
        List<Employee> emp = null;
        public ActionResult Index()
        {
            return View();
        }

        //To get all Employee List
        public ActionResult GetEmpDetails()
        {
            var emps = GetAllEmps();
            return View(emps);
        }

        //To Display an Employee by ID
        [HttpGet]
        public ActionResult GetEmpById()
        {

            return View();
        }

        [HttpPost]
        public ActionResult GetEmpById(int? Id)
        {
            var emps = GetAllEmps().Where(o => o.EmpId == Id).FirstOrDefault();
         
            return RedirectToAction("DisplayEmp", new RouteValueDictionary(emps));
        }

        //To Display an Employee
        public ActionResult DisplayEmp(Employee emps)
        {
            return View(emps);
        }
        //To Add an Employee
        [HttpGet]
        public ActionResult AddEmp()
        {
            return View();
        }

        [HttpPost]
        public ActionResult AddEmp(int? EmpId,string EmpName,int? Salary)
        {
            var id = EmpId;
            var ename = EmpName;
            var salary = Salary;

            Employee e = new Employee
            {
                EmpId =(int) id,
                EmpName = ename,
                Salary = (int)salary
            };

            var emps = GetAllEmps();
            emps.Add(e);
            //redirect to GetEmpDateails view
            return View("GetEmpDetails", emps);
        }

        //TO Delete an Employee
        public ActionResult DeleteEmp(Employee e)
        {
            //var id = EmpId;
            var emps = GetAllEmps();
            emps.Remove(e);
            return View("GetEmpDetails", emps);
        }

        [NonAction]
        public List<Employee> GetAllEmps()
        {
             emp = new List<Employee>
            {
                new Employee { EmpId = 1 , EmpName = "Ravi", Salary = 3000},
                new Employee { EmpId = 2 , EmpName = "Sam", Salary = 2000},
                new Employee { EmpId = 3 , EmpName = "Harsh", Salary = 3300},
                new Employee { EmpId = 4 , EmpName = "Akshay", Salary = 3300},
                new Employee { EmpId = 5 , EmpName = "Dan", Salary = 3300},
                new Employee { EmpId = 6 , EmpName = "Ram", Salary = 3300},
                new Employee { EmpId = 7 , EmpName = "John", Salary = 3300},
                new Employee { EmpId = 8 , EmpName = "Jessica", Salary = 3300}
            };
            return emp;
        }
    }
}